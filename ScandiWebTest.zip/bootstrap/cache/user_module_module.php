<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\UserModule\\Providers\\UserModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\UserModule\\Providers\\UserModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);