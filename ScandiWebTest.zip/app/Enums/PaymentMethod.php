<?php

namespace App\Enums;

class PaymentMethod
{
    const CASH = "cash";
    const WIRE_TRANSFER = "wire-transfer";

}
