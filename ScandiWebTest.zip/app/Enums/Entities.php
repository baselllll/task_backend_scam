<?php

namespace App\Enums;

class Entities
{
    const COMPANY = "company";
    const WORKSHOP = "workshop";
    const COLLECTOR = "collector";
    const USER = "user";

}
