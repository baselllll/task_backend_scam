<?php

namespace App\Enums;

class Platforms
{
    const WEB = "web";
    const ANDROID = "android";
    const IOS = "ios";
}
