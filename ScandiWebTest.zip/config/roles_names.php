<?php

return [
    //roles name
    "role"=>
    [
        "admin"=>"admin",
        "super_admin"=>"super_admin",
        "user"=>"user"
    ]
]

?>