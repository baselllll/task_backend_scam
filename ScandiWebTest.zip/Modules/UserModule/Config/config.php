<?php

return [
    'name' => 'UserModule'
];
